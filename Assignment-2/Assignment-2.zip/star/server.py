import socket
import json
import os

dst_ip = "10.0.1.3"

s = socket.socket()

dport = 12346

s.bind((dst_ip, dport))
print("socket binded to %s" % (dport))

s.listen(5)
print("socket is listening")

def load_data(path="server.json"):
    '''Check whether file and returns content in it in form of dictionary'''
    if os.path.exists(path):
        with open(path, "r") as f:
            data = json.load(f)
        return data
    else:
        return {}

def save_data(data,path="server.json"):
    '''Takes data which is dictionary objectand writes it into given json file'''
    with open(path, "w") as f:
        json.dump(data, f)

# Write your code here
    # 1. Uncomment c.send
    # 2. Parse the received HTTP request
    # 3. Do the necessary operation depending upon whether it is GET, PUT or DELETE
    # 4. Send response
    ##################        

def send_response(request, c):
    '''Takes request string, parses it and send appropriate response to client'''
    splitted = request.split(" ")
    request_type = splitted[0]
    res = "HTTP/1.1 400 Bad Request\r\n\r\n"
    if(request_type == "GET"):
        if("request=" in request):
            # check whether HTTP request has request="" format
            split_by_request_keyword = request.split("request=")[1]
            key = split_by_request_keyword.split(" ")[0]
            dict = load_data()
            if(key in dict.keys()):
                res = "HTTP/1.1 200 OK "+dict[key]+"\r\n\r\n"
                c.send(res.encode())
            else:
                res = "HTTP/1.1 404 Not Found\r\n\r\n"
                c.send(res.encode())
        else:
            c.send(res.encode())
    elif(request_type == "PUT"):
        try:
            key, value = splitted[1][13:].split("/")
            dict = load_data()
            dict[key] = value
            save_data(dict)
            print("Added key-val pair...")
            res = "HTTP/1.1 200 OK\r\n\r\n"
            c.send(res.encode())
        except Exception as e:
            print("Exception : ",e)
            c.send(res.encode())
    elif(request_type == "DELETE"):
        try:
            key = splitted[1][13:]
            dict = load_data()
            if(key in dict.keys()):
                del dict[key]
                save_data(dict)
                print("Deleted key-val pair...")
                res = "HTTP/1.1 200 OK\r\n\r\n"
                c.send(res.encode())
            else:
                res = "HTTP/1.1 404 Not Found\r\n\r\n"
                c.send(res.encode())
        except Exception as e:
            c.send(res.encode())
    else:
        print("Request :", request)
        c.send(res.encode())

c, addr = s.accept()
print('Got connection from', addr)
recvmsg = c.recv(1024).decode()
print('Server received '+recvmsg)
c.send('Hello cache'.encode()) # one time connection establishment between server and cache 

while True:
    # processing stream of requests as per persistent HTTP/1.1 protocol without reopening new socket 
    recvmsg = str(c.recv(1024).decode())
    if(recvmsg=="END Close-Connection"):
        print("Connection closed")
        res = "Connection closed"
        c.send(res.encode())
        break
    if(recvmsg):
        send_response(str(recvmsg), c)

c.close() # closing after all processed requests