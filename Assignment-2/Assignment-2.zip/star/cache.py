import socket
import json
import os

server_ip = "10.0.1.3"
dst_ip = "10.0.1.2" 

# cache acts as server for client and client for original server

dport = 12346

client_socket = socket.socket()
server_socket = socket.socket()

client_socket.bind((dst_ip, dport))
print("socket binded to %s" % (dport))

client_socket.listen(5)
print("socket is listening")

def request_generator(request_type="GET",*args):
    ''' This function takes request_type and args as arguments where request_type tells whether request is 
    PUT/DELETE/GET and args are corresponding keys (or) values needed for those requests'''
    if(request_type=="GET"):
        return r"GET /assignment2?request="+args[0]+r" HTTP/1.1"+"\r\n\r\n"

    elif(request_type=="PUT"):
        return r"PUT /assignment2/"+args[0]+r"/"+args[1]+r" HTTP/1.1"+"\r\n\r\n"

    elif(request_type=="DELETE"):
        return r"DELETE /assignment2/"+args[0]+r" HTTP/1.1"+"\r\n\r\n"

    else:
        return None

def response_parser(request_type,msg):
    ''' This function takes request_type as argument where request_type tells whether request is PUT/DELETE/GET
    and returns parsed response from server'''
    splitted = msg.split(" ")
    protocol = splitted[0]
    response_code = splitted[1]
    if(request_type=="GET"):
        if("200" in msg):
            final_msg = ""
            for i in range(3,len(splitted)):
                # connecting all last words after "OK" into one string
                final_msg+=splitted[i]
            return {"protocol":protocol,"response_code":response_code,"value":final_msg,"status":"SUCCESS"}
        else:
            final_msg = ""
            for i in range(2,len(splitted)):
                # connecting all last words after "400/404" into one string
                final_msg+=splitted[i]
            return {"protocol":protocol,"response_code":response_code,"value":final_msg,"status":"FAILED"}

    elif(request_type=="PUT"):
        s = "CREATED" if "200" in msg else "FAILED"
        return {"protocol":protocol,"response_code":response_code,"status":s}

    elif(request_type=="DELETE" or request_type=="END"):
        s = "SUCCESS" if "200" in msg else "FAILED"
        return {"protocol":protocol,"response_code":response_code,"status":s}

    else:
        return None

def load_data(path="cache.json"):
    '''Check whether file and returns content in it in form of dictionary'''
    if os.path.exists(path):
        with open(path, "r") as f:
            data = json.load(f)
        return data
    else:
        return {}

def save_data(data,path="cache.json"):
    '''Takes data which is dictionary objectand writes it into given json file'''
    with open(path, "w") as f:
        json.dump(data, f)

def send_response(request,c,server_socket):
    '''Takes request string, parses it and send appropriate response to client'''
    splitted = request.split(" ")
    request_type = splitted[0]
    res = "HTTP/1.1 400 Bad Request Cache\r\n\r\n"
    if(request_type == "GET"):
        if("request=" in request):
            # check whether HTTP request has request="" format
            split_by_request_keyword = request.split("request=")[1]
            key = split_by_request_keyword.split(" ")[0]
            dict = load_data()
            if(key in dict.keys()):
                print("key is already in Cache...")
                res = "HTTP/1.1 200 OK Cache:"+dict[key]+"\r\n\r\n"
                c.send(res.encode())
            else:
                response_string = request_generator("GET",key)
                server_socket.send(response_string.encode())
                res = server_socket.recv(1024).decode()
                parsed = response_parser("GET",res)
                if("200" in res):
                    print("Caching the key-val pair that we got from server...")
                    dict[key] = parsed["value"].split("\r\n\r\n")[0]
                save_data(dict)
                c.send(res.encode())
        else:
            c.send(res.encode())
    elif(request_type == "PUT"):
        try:
            key, value = splitted[1][13:].split("/")
            response_string = request_generator("PUT",key,value)
            server_socket.send(response_string.encode())
            res = server_socket.recv(1024).decode()
            c.send(res.encode())
        except Exception as e:
            print("Exception : ",e)
            c.send(res.encode())
    elif(request_type == "DELETE"):
        try:
            key = splitted[1][13:]
            response_string = request_generator("DELETE",key)
            server_socket.send(response_string.encode())
            res = server_socket.recv(1024).decode()
            c.send(res.encode())
        except Exception as e:
            c.send(res.encode())
    else:
        print("Request :", request)
        c.send(res.encode())

server_socket.connect((server_ip,dport))
server_socket.send("Hello server".encode())
print("Cache received "+server_socket.recv(1024).decode()) # one time connection between cache server and server 

c, addr = client_socket.accept()
print('Got connection from', addr)
recvmsg = c.recv(1024).decode()
print('Cache Server received '+recvmsg)
c.send('Hello client'.encode()) # one time connection establishment between cache server and client 

while True:
    # processing stream of requests as per persistent HTTP/1.1 protocol without reopening new socket 
    recvmsg = str(c.recv(1024).decode())
    if(recvmsg=="END Close-Connection"):
        print("Connection closed")
        res = "Connection closed"
        c.send(res.encode())
        print("Server connection closed")
        server_socket.send(recvmsg.encode())
        break
    if(recvmsg):
        send_response(str(recvmsg), c,server_socket)

c.close() # closing after all processed requests