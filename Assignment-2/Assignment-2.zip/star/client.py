import socket
import time

serverIP = "10.0.1.2"
dst_ip = serverIP

s = socket.socket()

port = 12346

#Write your code here:
#1. Add code to send HTTP GET / PUT / DELETE request. The request should also include KEY.
#2. Add the code to parse the response you get from the server.

def request_generator(request_type="GET",*args):
	''' This function takes request_type and args as arguments where request_type tells whether request is 
	PUT/DELETE/GET and args are corresponding keys (or) values needed for those requests'''
	if(request_type=="GET"):
		return r"GET /assignment2?request="+args[0]+r" HTTP/1.1"+"\r\n\r\n"

	elif(request_type=="PUT"):
		return r"PUT /assignment2/"+args[0]+r"/"+args[1]+r" HTTP/1.1"+"\r\n\r\n"

	elif(request_type=="DELETE"):
		return r"DELETE /assignment2/"+args[0]+r" HTTP/1.1"+"\r\n\r\n"

	else:
		return None

def response_parser(request_type,msg):
	''' This function takes request_type as argument where request_type tells whether request is PUT/DELETE/GET
	and returns parsed response from server'''
	splitted = msg.split(" ")
	protocol = splitted[0]
	response_code = splitted[1]
	if(request_type=="GET"):
		if("200" in msg):
			final_msg = ""
			for i in range(3,len(splitted)):
				# connecting all last words after "OK" into one string
				final_msg+=splitted[i]
			return {"protocol":protocol,"response_code":response_code,"value":final_msg,"status":"SUCCESS"}
		else:
			final_msg = ""
			for i in range(2,len(splitted)):
				# connecting all last words after "400/404" into one string
				final_msg+=splitted[i]
			return {"protocol":protocol,"response_code":response_code,"value":final_msg,"status":"FAILED"}

	elif(request_type=="PUT"):
		s = "CREATED" if "200" in msg else "FAILED"
		return {"protocol":protocol,"response_code":response_code,"status":s}

	elif(request_type=="DELETE" or request_type=="END"):
		s = "SUCCESS" if "200" in msg else "FAILED"
		return {"protocol":protocol,"response_code":response_code,"status":s}

	else:
		return None

try:
	s.connect((dst_ip, port))
	s.send('Hello server'.encode())
	print ('Client received '+s.recv(1024).decode())



	# Code block 1
	# key store creating at server using client side PUT Request for star (a) part

	request_string = request_generator("PUT","key1","val1")
	print(request_string)
	s.send(request_string.encode())
	res = s.recv(1024).decode()
	print(response_parser("PUT",res)) 



	# Code block 2
	# Performing GET requests for star (a) part

	# request_string = request_generator("GET","key1")
	# print(request_string)
	# s.send(request_string.encode())
	# res = s.recv(1024).decode()
	# print(response_parser("GET",res))



	# Code block 3
	# key store creating at server using client side PUT Requests for star (b) part
	
	# for i in range(1,7):
	# 	key = "Key"+str(i)
	# 	value = "Val"+str(i)
	# 	request_string = request_generator("PUT",key,value)
	# 	print(request_string)
	# 	s.send(request_string.encode())
	# 	res = s.recv(1024).decode()
	# 	print(response_parser("PUT",res)) # printing response from server after parsing 



	# Code block 4
	# Performing GET requests for star (b) part

	# for i in range(1,7):
	# 	key = "Key"+str(i)
	# 	request_string = request_generator("GET",key)
	# 	print(request_string)
	# 	s.send(request_string.encode())
	# 	res = s.recv(1024).decode()
	# 	print(response_parser("GET",res)) # printing response from server after parsing 



	request_string = "END Close-Connection"
	s.send(request_string.encode())
	res = s.recv(1024).decode()
	print(res)

	s.close()	
except Exception as e:
	print("Error occured",e)